/** Automatically generated file. DO NOT MODIFY */
package us.bssoft.hangman;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}